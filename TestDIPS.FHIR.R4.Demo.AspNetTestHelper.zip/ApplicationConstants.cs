﻿using System;

namespace $safeprojectname$
{
    internal class ApplicationConstants
    {
        internal static string ApplicationName = "ANC Data Access Handler";
        internal static readonly int ApplicationId = 100000;
        internal static readonly Guid SessionId = Guid.NewGuid();
    }
}