﻿using DIPS.Fhir.R4.Demo.Server.DB;
using DIPS.FHIR.R4.Demo.Server;
using DIPS.Infrastructure.HealthCheck;
using DIPS.Infrastructure.Profiling;
using DIPS.Infrastructure.Profiling.AspNetCore;
using DIPS.Infrastructure.Profiling.Sink.Logging;
using DIPS.Infrastructure.Security.Server.AspNetCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Add Oracle database provider
            services.AddOracleDbProvider((sp, options) 
                => options.ConnectionString = Configuration.BuildConnectionString());

            services.AddDbConnection();

            // Add profiling using values from ApplicationConstants
            services.AddProfiling(options =>
            {
                options.ApplicationId = () => ApplicationConstants.ApplicationId;
                options.SessionId = () => ApplicationConstants.SessionId;
            });

            // Add profiling sink
            services.AddSingleton<IProfilingWriter>(sp => new LogProfilingWriter());

            // Add authentication that supports both ticket and jwt 
            services.AddInternalAuthentication(Configuration, options => 
            { 
                // Set to true to allow JWT. Requires security:authority configuration setting
                options.AllowJwt = false; 
                options.AllowTicket = true; 
                
                // Set security token (ticket) on dbConnection when creating new connection
                // Required when updating data in DIPS database
                options.SetSecurityTokenOnDbProviderFactory = true;
            });

            // TODO: Register services here 
            services.AddScoped<IFhirIdDemoServiceStore, FhirIdDemoServiceStore>();
           
            services
                .AddMvc(options => 
                { 
                    // Require authorized user for all calls. To allow anonymous call add [AllowAnonymous] to method or controller 
                    var policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build(); 
                    options.Filters.Add(new AuthorizeFilter(policy)); 
                    
                    // Rewrite ticket exception from Oracle DIPS database to 401
                    options.Filters.Add(new InternalSecurityExceptionFilter());
                    
                    // Call cpSession.ClearSession when leaving service. This is required when using DIPS database and security token
                    options.Filters.Add(new InternalSecurityActionFilter());
                }) 
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            services.AddHealthChecks()
                // Add specific health checks here
                .AddDatabaseConnectionHealthCheck();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        [System.Obsolete]
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseProfiling();
            app.AddHealthCheckEndpoints();


            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseAuthentication();
            app.UseMvc();
        }
    }
}
