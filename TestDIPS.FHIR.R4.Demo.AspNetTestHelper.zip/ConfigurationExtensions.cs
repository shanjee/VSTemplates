﻿using Microsoft.Extensions.Configuration;

namespace $safeprojectname$
{
    internal static class ConfigurationExtensions
    {
        internal static string BuildConnectionString(this IConfiguration config)
        {
            var dataSource = config.GetValue<string>("Database:DataSource");
            var userName = config.GetValue<string>("Database:az-sea-fl-db02.dipscloud.com/dips:UserId") ?? "fhir_app";
            var password = config.GetValue<string>("Database:fhir_app:Password");
            return $"Data Source={dataSource};User Id={userName};Password={password}";
        }
    }
}
