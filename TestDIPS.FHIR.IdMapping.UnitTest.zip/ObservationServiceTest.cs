using DIPS.FHIR.R4.Demo.Server;
using DIPS.Infrastructure.Security;
using DIPS.SmartEhr.Client;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace $safeprojectname$
{
    [TestClass]
    public class ObservationServiceTest
    {
        private FhirIdDemoService m_demoService;
       
        private Mock<IConfiguration> m_Configuration;
        private Mock<ISmartEhrClient> m_SmartEhrClient;
        private Mock<IUser> m_user;
        private string _path;
        bool IsDepId = false;

        [TestInitialize]
        public void Initialize()
        {
            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();
        }

        [TestMethod]
        public void Create_BloodPressure_Test()
        {
            
        }
    }
}
