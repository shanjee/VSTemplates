﻿using System;
using System.Data;
using Dapper.Oracle;

namespace $safeprojectname$.Utility
{
    public static class IdMapperQueryParamHelper
    {

        internal static OracleDynamicParameters UpdateSourceIdQueryParams(Guid fhirId, string sourceId)
        {
            var dynamicParameters = new OracleDynamicParameters();
            dynamicParameters.Add("P_FHIRID", GuidConvert.ToRaw(fhirId), OracleMappingType.Raw,
                ParameterDirection.Input, 16);
            dynamicParameters.Add("P_SOURCEID", sourceId, OracleMappingType.Varchar2, ParameterDirection.Input);

            return dynamicParameters;
        }

        internal static OracleDynamicParameters DeleteByFhirIdQueryParams(Guid fhirId)
        {
            var dynamicParameters = new OracleDynamicParameters();
            dynamicParameters.Add("P_FHIRID", GuidConvert.ToRaw(fhirId), OracleMappingType.Raw, ParameterDirection.Input, 16);
            return dynamicParameters;
        }

        internal static OracleDynamicParameters GetLatestVersionByExternalFhirIdQueryParams(string externalFhirId)
        {
            var dynamicParameters = new OracleDynamicParameters();
            dynamicParameters.Add("p_externalFhirId", externalFhirId, OracleMappingType.Varchar2, ParameterDirection.Input);
            dynamicParameters.Add("v_latestVersion", null, OracleMappingType.RefCursor, ParameterDirection.ReturnValue);

            return dynamicParameters;
        }

        internal static OracleDynamicParameters GetVersionByFhirIdQueryParams(Guid fhirId, string fhirVersion)
        {
            var dynamicParameters = new OracleDynamicParameters();
            dynamicParameters.Add("P_FHIRID", GuidConvert.ToRaw(fhirId), OracleMappingType.Raw, ParameterDirection.Input, 16);
            dynamicParameters.Add("P_VERSIONNUMBER", fhirVersion, OracleMappingType.Varchar2, ParameterDirection.Input);
            dynamicParameters.Add("v_version", null, OracleMappingType.RefCursor, ParameterDirection.ReturnValue);

            return dynamicParameters;
        }
    }
}
