﻿using System;

namespace $safeprojectname$.Utility
{
    public static class GuidConvert
    {
        public static byte[] ToRaw(Guid? value)
        {
            if (value == null)
            {
                return new byte[0];
            }

            return value.Value.ToByteArray();
        }

        public static Guid FromRaw(byte[] value)
        {
            if (value == null)
            {
                return Guid.Empty;
            }
            return new Guid(value);
        }

    }
}
