﻿#region Using Statements

using System;
using System.Data;
using System.Data.Common;
using Dapper;
using $safeprojectname$.Utility;
using $ext_safeprojectname$.Server;
using log4net;
using Oracle.ManagedDataAccess.Client;

#endregion

namespace $safeprojectname$
{
    public class FhirIdDemoServiceStore : IFhirIdDemoServiceStore
    {
        //private static readonly ILog s_log = LogProvider.GetCurrentClassLogger();
        private static readonly log4net.ILog s_log = LogManager.GetLogger(typeof(FhirIdDemoServiceStore));

        private readonly DbProviderFactory m_providerFactory;

        public FhirIdDemoServiceStore(DbProviderFactory providerFactory)
        {
            m_providerFactory = providerFactory;
        }
      

        public void UpdateSourceId(Guid fhirId, string sourceId)
        {
            try
            {
                using (var dbClient = m_providerFactory.CreateConnection())
                {
                    var dynamicParameters = IdMapperQueryParamHelper.UpdateSourceIdQueryParams(fhirId, sourceId);
                    var spName = "fhir_code.fhiridmapping.updatesourceid";
                    var result = dbClient.Execute(spName, dynamicParameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (OracleException ex)
            {
                s_log.Error("FhirIdMapper UpdateSourceId Fails(Error from Oracle)", ex);
                throw new Exception($"FhirIdMapper UpdateSourceId Fails(Error from Oracle. {ex}");
            }
            catch (Exception ex)
            {
                s_log.Error("FhirIdMapper UpdateSourceId Fails", ex);
                throw new Exception($"FhirIdMapper UpdateSourceId Fails. {ex}");
            }
        }

        public void DeleteByFhirId(Guid fhirId)
        {
            try
            {
                using (var dbClient = m_providerFactory.CreateConnection())
                {
                    var dynamicParameters = IdMapperQueryParamHelper.DeleteByFhirIdQueryParams(fhirId);
                    var spName = "fhir_code.fhiridmapping.deletebyfhirid";
                    //dbClient.QuerySingleOrDefault(spName, oracleParameters.ToArray());
                    dbClient.Execute(spName, dynamicParameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (OracleException ex)
            {
                s_log.Error("FhirIdMapper DeleteByFhirId Fails(Error from Oracle)", ex);
                throw new Exception($"FhirIdMapper DeleteByFhirId Fails(Error from Oracle. {ex}");
            }
            catch (Exception ex)
            {
                s_log.Error("FhirIdMapper DeleteByFhirId Fails", ex);
                throw new Exception($"FhirIdMapper DeleteByFhirId Fails. {ex}");
            }
        }
    }
}
