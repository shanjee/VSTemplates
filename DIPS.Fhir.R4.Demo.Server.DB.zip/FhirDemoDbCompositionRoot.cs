﻿using System.Data.Common;
using $ext_safeprojectname$.Server;
using LightInject;
using ICompositionRoot = LightInject.ICompositionRoot;


namespace $safeprojectname$
{
    public class FhirDemoDbCompositionRoot : ICompositionRoot
    {
        public void Compose(IServiceRegistry serviceRegistry)
        {
            serviceRegistry.Register<IFhirIdDemoServiceStore>(c => new FhirIdDemoServiceStore(c.GetInstance<DbProviderFactory>()));
        }
    }
}
