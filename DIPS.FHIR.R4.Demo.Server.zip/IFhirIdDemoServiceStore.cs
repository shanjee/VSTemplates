﻿using System;

namespace $safeprojectname$
{
    public interface IFhirIdDemoServiceStore
    {
        void UpdateSourceId(Guid fhirId, string sourceId);
        void DeleteByFhirId(Guid fhirId);
    }
}
