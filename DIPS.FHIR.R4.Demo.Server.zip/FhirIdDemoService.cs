﻿#region Using Statements

using System;
using DIPS.FHIR.R4.Demo.Common;
using DIPS.Infrastructure.Logging;
using LogProvider = DIPS.Infrastructure.Logging.LogProvider;

#endregion

namespace $safeprojectname$
{
    public class FhirIdDemoService : IFhirIdDemoService
    {
        #region Class variables        
        private static readonly ILog s_log = LogProvider.GetLogger(typeof(FhirIdDemoService));

        private readonly IFhirIdDemoServiceStore _mDemoServiceStore;
        #endregion

        public FhirIdDemoService(IFhirIdDemoServiceStore demoServiceStore)
        {
            _mDemoServiceStore = demoServiceStore;
        }


        public void UpdateSourceId(Guid fhirId, string sourceId)
        {
            throw new NotImplementedException();
        }

        public void DeleteByFhirId(Guid fhirId)
        {
            throw new NotImplementedException();
        }
    }
}