﻿using DIPS.FHIR.R4.Demo.Common;
using LightInject;
using ICompositionRoot = LightInject.ICompositionRoot;

namespace $safeprojectname$
{
    public class FhirServerCompositionRoot : ICompositionRoot
    {

        public void Compose(IServiceRegistry serviceRegistry)
        {
            serviceRegistry.Register<IFhirIdDemoService>(c => new FhirIdDemoService(c.GetInstance<IFhirIdDemoServiceStore>()));
        }
    }
}
