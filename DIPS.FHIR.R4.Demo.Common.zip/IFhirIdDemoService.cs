﻿using System;

namespace $safeprojectname$
{

    public interface IFhirIdDemoService
    {
        
        /// <summary>
        /// Update the Source Id
        /// </summary>
        /// <param name="fhirId">Dips Fhir id </param>
        /// <param name="sourceId">sourceId</param>
        //[OperationContract]
        void UpdateSourceId(Guid fhirId, string sourceId);

        
        /// <summary>
        /// Delete the record which matches to fhirId.
        /// </summary>
        /// <param name="fhirId">fhir id</param>
        //[OperationContract]
        void DeleteByFhirId(Guid fhirId);
    }
}
