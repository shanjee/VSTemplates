﻿using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$
{

    public class TestDataHelper 
    {
        public static IServiceScope serviceScope;

        //private TService GetInstance<TService>()
        //{
        //    return serviceScope.ServiceProvider.GetRequiredService<TService>();
        //}

        protected virtual TService GetInstance<TService>()
        {
            return serviceScope.ServiceProvider.GetRequiredService<TService>();
        }

    }
}
