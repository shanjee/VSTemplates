﻿using System.Transactions;
using DIPS.Infrastructure.Security;
using DIPS.Infrastructure.Security.Common.Implementation;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestDIPS.FHIR.R4.Demo.AspNetTestHelper;

namespace $safeprojectname$
{
    public class TestBase
    {
        // Factory for creating clients for the service that is being tested.
        private readonly WebApplicationFactory<Startup> _serviceUnderTestFactory;
        // Factory for creating test services to add testdata etc.
        public readonly WebApplicationFactory<Startup> _testFactory;
        // Scope for test classes, should be disposed on cleanup
        protected IServiceScope m_serviceScope;
        public TransactionScope m_transactionScope;

        protected long TestUserId;
        protected static long TestUserRoleId;
        protected static long TestHospitalId;

        public TestBase()
        {
            _serviceUnderTestFactory = new WebApplicationFactory<Startup>();
         
            _testFactory = _serviceUnderTestFactory.WithWebHostBuilder(config =>
            {
                config.ConfigureTestServices(services =>
                {
                    services.AddSingleton<ISecurityTokenStorage>(sp =>
                    {
                        var storage = new GlobalSecurityTokenStorage();

                        // server - 1
                        //storage.Set(SecurityConstants.TicketStorageConstant, "3fd00df2-02dd-488d-9b58-403f385ccc49");

                        // server - 2
                        storage.Set(SecurityConstants.TicketStorageConstant, "02591eea-57de-4d5a-9d66-c7f968c81afa");
                        return storage;
                    });
                });
            });
            _testFactory.CreateDefaultClient();
        }

        protected virtual TService GetInstance<TService>()
        {
            return m_serviceScope.ServiceProvider.GetRequiredService<TService>();
        }

        [TestInitialize]
        public void TestInitialize()
        {
            m_serviceScope = _testFactory.Server.Host.Services.CreateScope();
            m_transactionScope = new TransactionScope();
            TestDataHelper.serviceScope = m_serviceScope;

            var config = GetInstance<IConfiguration>();

            TestUserId = config.GetValue<long>("TestUserId", 179);
            TestUserRoleId = config.GetValue<long>("TestUserRoleId", 132);
            TestHospitalId = config.GetValue<long>("TestHospitalId", 1);
        }

        [TestCleanup]
        public void TestCleanup()
        {
            m_serviceScope.Dispose();
            m_transactionScope.Dispose();
        }
    }
}
