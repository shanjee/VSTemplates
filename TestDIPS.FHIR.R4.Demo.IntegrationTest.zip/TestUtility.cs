﻿using System.IO;

namespace $safeprojectname$
{
    public static class TestUtility
    {
        static string GetRandomString()
        {
            string name = Path.GetRandomFileName();
            name = name.Replace(".", "");
            return name;
        }
    }
}
