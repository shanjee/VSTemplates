﻿using System;
using System.Linq;
using System.Transactions;
using DIPS.Fhir.R4.Demo.Server.DB;
using DIPS.FHIR.R4.Demo.Server;

using DIPS.Infrastructure.Container;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $safeprojectname$
{
    [TestClass]
    public class FhirIdDemoDbIntegrationTest: TestBase
    {
        private IFhirIdDemoServiceStore _mFhirIdDemoServiceStore;
        //private static DatabaseIntegrationTestHelper _testHelper;
        //private TestUtility m_testUtility;
        //private IDbClientFactory m_dbClientFactory;

        [TestInitialize]
        public void Init()
        {
            m_serviceScope = _testFactory.Server.Host.Services.CreateScope();
            m_transactionScope = new TransactionScope();
            TestDataHelper.serviceScope = m_serviceScope;

            var config = GetInstance<IConfiguration>();

            TestUserId = config.GetValue<long>("TestUserId", 179);
            TestUserRoleId = config.GetValue<long>("TestUserRoleId", 132);
            TestHospitalId = config.GetValue<long>("TestHospitalId", 1);
        }

        [TestCleanup]
        public void Cleanup()
        {
            //_testHelper.OnTestComplete();
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            //_testHelper.Dispose();
        }

        private static void InitializeContainer(IContainer container)
        {
            //container.Register(c => new FhirIdDemoServiceStore(c.Get<IDbClientFactory>()), ContainerScope.Transient);
            //container.Register(c => new FhirIdDemoService(c.Get<IFhirIdDemoServiceStore>()), ContainerScope.Transient);
        }

        [TestMethod, TestCategory("IntegrationTest")]
        public void Insert_MappingData_shouldReturnsGuid()
        {
            var domainEvenDatatService = GetInstance<IFhirIdDemoServiceStore>();
            //var fhirId = domainEvenDatatService.InsertMappingData(TestUtility.GetFhirIdMappingRequest(), OperationType.Create, true);
            Assert.AreNotEqual(string.Empty, Guid.Empty);
        }
    }
}
